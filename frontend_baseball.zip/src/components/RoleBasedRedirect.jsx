import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function RoleBasedRedirect() {
  const { isAuthenticated, getDashboardRoute } = useAuth();

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Get the appropriate dashboard route based on user role
  const dashboardRoute = getDashboardRoute();
  
  // Redirect to the user's appropriate dashboard
  return <Navigate to={dashboardRoute} replace />;
}
