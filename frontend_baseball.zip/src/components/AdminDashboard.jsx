import { useState } from "react";
import { 
  ArrowLeft, 
  Users, 
  BookOpen, 
  Video, 
  Settings, 
  Shield,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  BarChart3,
  FileText,
  Database
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export function AdminDashboard({ onBack, onViewCoachDashboard }) {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-green-50/30 to-blue-50/30 tech-grid">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-72 h-72 bg-green-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: "1s" }} />
      </div>

      {/* Header */}
      <header className="relative border-b border-white/20 glass-panel shadow-lg">
        <div className="container mx-auto px-4 md:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-all hover:gap-3 group"
              >
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                <span>Back</span>
              </button>
              <div className="w-px h-6 bg-border" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/30">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-foreground">Admin Dashboard</h1>
                  <p className="text-sm text-muted-foreground">Full platform control</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button
                onClick={onViewCoachDashboard}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                <BarChart3 className="w-4 h-4" />
                Coach View
              </Button>
              <div className="relative w-2 h-2">
                <div className="absolute inset-0 w-2 h-2 rounded-full bg-purple-500 animate-ping" />
              </div>
              <span className="text-sm font-medium text-foreground">Admin Mode</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative container mx-auto px-4 md:px-6 py-6 md:py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
          <div className="glass-panel rounded-2xl p-6 border border-white/30 shadow-lg hover:shadow-xl transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
                <Users className="w-6 h-6 text-white" />
              </div>
              <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                <Edit className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground font-medium mb-1">Total Users</p>
            <p className="text-3xl font-bold text-foreground">247</p>
            <p className="text-xs text-muted-foreground mt-2">35 admins • 12 coaches • 200 players</p>
          </div>

          <div className="glass-panel rounded-2xl p-6 border border-white/30 shadow-lg hover:shadow-xl transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-lg shadow-green-500/30">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground font-medium mb-1">Situations</p>
            <p className="text-3xl font-bold text-foreground">45</p>
            <p className="text-xs text-muted-foreground mt-2">15 standard • 30 advanced</p>
          </div>

          <div className="glass-panel rounded-2xl p-6 border border-white/30 shadow-lg hover:shadow-xl transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Video className="w-6 h-6 text-white" />
              </div>
              <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground font-medium mb-1">Training Videos</p>
            <p className="text-3xl font-bold text-foreground">23</p>
            <p className="text-xs text-muted-foreground mt-2">18 uploaded • 5 pending</p>
          </div>

          <div className="glass-panel rounded-2xl p-6 border border-white/30 shadow-lg hover:shadow-xl transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/30">
                <Database className="w-6 h-6 text-white" />
              </div>
              <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground font-medium mb-1">Total Sessions</p>
            <p className="text-3xl font-bold text-foreground">1,847</p>
            <p className="text-xs text-muted-foreground mt-2">342 this week</p>
          </div>
        </div>

        {/* Management Tabs */}
        <div className="glass-panel rounded-3xl shadow-xl border border-white/30 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="border-b border-white/20 bg-gradient-to-r from-purple-500/10 to-blue-500/10">
              <TabsList className="w-full justify-start p-4 bg-transparent h-auto">
                <TabsTrigger value="overview" className="data-[state=active]:bg-white/50">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="users" className="data-[state=active]:bg-white/50">
                  <Users className="w-4 h-4 mr-2" />
                  User Management
                </TabsTrigger>
                <TabsTrigger value="content" className="data-[state=active]:bg-white/50">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Content Management
                </TabsTrigger>
                <TabsTrigger value="videos" className="data-[state=active]:bg-white/50">
                  <Video className="w-4 h-4 mr-2" />
                  Video Library
                </TabsTrigger>
                <TabsTrigger value="settings" className="data-[state=active]:bg-white/50">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </TabsTrigger>
              </TabsList>
            </div>

            {/* Overview Tab */}
            <TabsContent value="overview" className="p-6">
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-foreground mb-4">Platform Overview</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="glass-panel rounded-2xl p-6 border border-white/20">
                      <h3 className="font-semibold text-foreground mb-4">Recent Activity</h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">New user registered</span>
                          <span className="text-xs text-muted-foreground">2 min ago</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Video uploaded: "Double Play"</span>
                          <span className="text-xs text-muted-foreground">15 min ago</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Situation created: "Bunt Defense"</span>
                          <span className="text-xs text-muted-foreground">1 hour ago</span>
                        </div>
                      </div>
                    </div>

                    <div className="glass-panel rounded-2xl p-6 border border-white/20">
                      <h3 className="font-semibold text-foreground mb-4">Quick Actions</h3>
                      <div className="space-y-2">
                        <Button className="w-full justify-start" variant="outline">
                          <Plus className="w-4 h-4 mr-2" />
                          Add New User
                        </Button>
                        <Button className="w-full justify-start" variant="outline">
                          <Plus className="w-4 h-4 mr-2" />
                          Create Situation
                        </Button>
                        <Button className="w-full justify-start" variant="outline">
                          <Plus className="w-4 h-4 mr-2" />
                          Upload Video
                        </Button>
                        <Button className="w-full justify-start" variant="outline">
                          <FileText className="w-4 h-4 mr-2" />
                          Generate Report
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* User Management Tab */}
            <TabsContent value="users" className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-foreground">User Management</h2>
                  <Button className="bg-gradient-to-r from-purple-600 to-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add User
                  </Button>
                </div>

                {/* Search and filters */}
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Search users..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 bg-white/50 border-white/30"
                    />
                  </div>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                </div>

                {/* Users table */}
                <div className="glass-panel rounded-2xl border border-white/20 overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-white/20 bg-white/30">
                        <th className="text-left p-4 text-sm font-medium">User</th>
                        <th className="text-left p-4 text-sm font-medium">Role</th>
                        <th className="text-left p-4 text-sm font-medium">Status</th>
                        <th className="text-left p-4 text-sm font-medium">Joined</th>
                        <th className="text-right p-4 text-sm font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Sample rows */}
                      <tr className="border-b border-white/10 hover:bg-white/30 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center font-semibold text-white">
                              AS
                            </div>
                            <div>
                              <p className="font-medium">Admin Smith</p>
                              <p className="text-xs text-muted-foreground">admin@fieldiq.com</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="px-3 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded-lg">
                            Admin
                          </span>
                        </td>
                        <td className="p-4">
                          <span className="inline-flex items-center gap-1 text-sm text-green-600">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                            Active
                          </span>
                        </td>
                        <td className="p-4 text-sm text-muted-foreground">Jan 1, 2024</td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr className="border-b border-white/10 hover:bg-white/30 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center font-semibold text-white">
                              CS
                            </div>
                            <div>
                              <p className="font-medium">Coach Smith</p>
                              <p className="text-xs text-muted-foreground">coach@fieldiq.com</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-lg">
                            Coach
                          </span>
                        </td>
                        <td className="p-4">
                          <span className="inline-flex items-center gap-1 text-sm text-green-600">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                            Active
                          </span>
                        </td>
                        <td className="p-4 text-sm text-muted-foreground">Feb 15, 2024</td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </TabsContent>

            {/* Content Management Tab */}
            <TabsContent value="content" className="p-6">
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="font-semibold text-foreground mb-2">Content Management</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Manage defensive situations, descriptions, and training content
                </p>
                <Button className="bg-gradient-to-r from-green-600 to-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Create New Situation
                </Button>
              </div>
            </TabsContent>

            {/* Videos Tab */}
            <TabsContent value="videos" className="p-6">
              <div className="text-center py-12">
                <Video className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="font-semibold text-foreground mb-2">Video Library</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Upload and manage training videos for each defensive situation
                </p>
                <Button className="bg-gradient-to-r from-purple-600 to-purple-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Upload Video
                </Button>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="p-6">
              <div className="text-center py-12">
                <Settings className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="font-semibold text-foreground mb-2">Platform Settings</h3>
                <p className="text-sm text-muted-foreground">
                  Configure platform settings, permissions, and preferences
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
